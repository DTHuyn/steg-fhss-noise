import numpy as np
import scipy.signal as signal
import scipy.io.wavfile as wav

def bandpass_filter(sig, lowcut, highcut, fs, order=6):
    nyq = 0.5 * fs
    b, a = signal.butter(order, [lowcut/nyq, highcut/nyq], btype='band')
    return signal.filtfilt(b, a, sig)

def extract_bits(input_wav, hopping_file, bit_duration=0.01, base_freq=2000, delta=100):
    fs, noisy_signal = wav.read(input_wav)
    if noisy_signal.ndim > 1:
        noisy_signal = noisy_signal[:, 0]
    noisy_signal = noisy_signal.astype(np.float32) / 32768.0

    with open(hopping_file, 'r') as f:
        hopping_pattern = list(map(int, f.read().strip().split()))

    samples_per_bit = int(bit_duration * fs)
    num_bits = len(noisy_signal) // samples_per_bit

    if len(hopping_pattern) < num_bits:
        times = (num_bits // len(hopping_pattern)) + 1
        hopping_pattern = (hopping_pattern * times)[:num_bits]

    extracted_bits = []
    for i in range(num_bits):
        segment = noisy_signal[i * samples_per_bit: (i + 1) * samples_per_bit]
        hop = hopping_pattern[i]
        f0 = base_freq + hop * delta
        f1 = base_freq + (hop + 1) * delta

        filtered_f0 = bandpass_filter(segment, f0 - 30, f0 + 30, fs)
        filtered_f1 = bandpass_filter(segment, f1 - 30, f1 + 30, fs)

        power_f0 = np.sum(filtered_f0 ** 2)
        power_f1 = np.sum(filtered_f1 ** 2)

        extracted_bits.append('1' if power_f1 > power_f0 else '0')

    return extracted_bits, fs, num_bits, samples_per_bit

def bits_to_string(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        char = chr(int(''.join(byte), 2))
        if char == '\0':
            break
        chars.append(char)
    return ''.join(chars)

def main():
    input_wav = "stego_audio.wav"
    hopping_file = "hopping_pattern.txt"
    output_message = "message_hide.txt"

    extracted_bits, fs, num_bits, samples_per_bit = extract_bits(input_wav, hopping_file)
    #print(f"File âm thanh có thể chứa: {num_bits} bit, len(signal)={fs*num_bits/samples_per_bit}, fs={fs}, samples_per_bit={samples_per_bit}")

    message = bits_to_string(extracted_bits)
    with open(output_message, 'w') as f:
        f.write(message)
    print(f"Đã lưu thông điệp tại {output_message}: {message}")

if __name__ == "__main__":
    main()
